
import './App.css';
import Header from './Components/Header';
import Navbar from './Components/Navbar';
import Business from './Components/Business';
import Wherever from './Components/Wherever';
import Closet from './Components/Closet';
import Way from './Components/Way'
import Footer from './Components/Footer'
import Globe from './Components/Globe'

function App() {
  return (
    <div className="App">
      <Navbar />
      <Header />
      <Business />
      <Wherever />
      <Globe />
      <Closet />
      <Way />
      <Footer />
    </div>
  );
}

export default App;
