import React from "react";
import img from "./assets/Globe.png";

function Globe() {
  return (
    <div>
      <img src={img} alt="" />
    </div>
  );
}

export default Globe;
