import React from "react";
import vids from "./assets/vids.mp4";
import "./Wherever.css";

function Wherever() {
  return (
    <div className="container">
      <div>
        <h1 className="text-center mt-5">With you wherever you’re going</h1>
        <p className="text-muted text-center">
          One platform with all the ecommerce and point of sale features you
          need to start, run, and grow your business.
        </p>
        <div className="row">
          <div className="col-md-6">
            <video
              height={"400px"}
              muted="muted"
              loop
              autoPlay
              data-lazyload="true"
              src={vids}
              type="video/mp4"
            ></video>
          </div>
          <div className="col-md-6 justify-content-center ALign">
            <h1>Sell Everywhere</h1>
            <p className="text-muted">
              Use one platform to sell products to anyone, anywhere—in person
              with Point of Sale and online through your website, social media,
              and online marketplaces.
            </p>
            <a className="text-dark" href="0">
              Explore ways to sell
            </a>
          </div>
        </div>

        <div className="row">
          <div className="col-md-6 ALign">
            <h1>Market your business</h1>
            <p>
              Take the guesswork out of marketing with built-in tools that help
              you create, execute, and analyze digital marketing campaigns.
            </p>
            <a className="text-dark" href="0">
              Explore how to market your business
            </a>
          </div>
          <div className="col-md-6">
            <img
              src="https://cdn.shopify.com/shopifycloud/brochure/assets/home/market-small-084eab2d72b510555838c446501d27dd7380585450efcaaa97453289b2b69c79.jpg"
              alt=""
              height={"450px"}
            />
          </div>
        </div>

        <div className="row">
          <div className="col-md-6">
            <img
              src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTF3jTyPHsaSBhpUrPSRhYjy6MLslZNW6AQ1A44V8MNjlJR1ir6"
              alt=""
              height={"350px"}
            />
          </div>
          <div className="col-md-5 ALigN">
            <h1>Manage everything</h1>
            <p className="text-muted">
              Gain the insights you need to grow—use a single dashboard to
              manage orders, shipping, and payments anywhere you go.
            </p>
            <a className="text-dark" href="0">
              Explore how to manage your business
            </a>
          </div>
        </div>
        <h2 className="pt-5">
          Empowering independent business <br />
          owners everywhere
        </h2>
        <h4 className="pt-3">
          Millions of businesses in 175 countries around the world have <br />{" "}
          made over $200 billion USD in sales using Shopify.
        </h4>
        <a className="text-dark" href="0">
          Learn more about Shopify{" "}
        </a>
      </div>
    </div>
  );
}

export default Wherever;
