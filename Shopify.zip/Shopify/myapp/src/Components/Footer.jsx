import React from "react";
import "./Footer.css";

function Footer() {
  return (
    <div>
      <div className="Foot mt-5">
        <div className="container">
          <div className="pt-5">
            <span className="SPan px-3">About</span>
            <span className="SPan px-3">Careers</span>
            <span className="SPan px-3">Press and Media</span>
            <span className="SPan px-3">Shopify plus</span>
            <span className="SPan px-3">Sitemap</span>
          </div>

          <div className="row pt-5">
            <div className="col-md-2">
              <h6 className="text-white">ONLINE STORE</h6>
              <p className="ppaa">Sell online</p>
              <p className="ppaa">Features</p>
              <p className="ppaa">Example</p>
              <p className="ppaa">Website Editor</p>
              <p className="ppaa">Online Retail</p>
            </div>
            <div className="col-md-2">
              <h6 className="text-white et">ONLINE STORE</h6>
              <p className="ppaa">Ecommerce website</p>
              <p className="ppaa">Domain names</p>
              <p className="ppaa">Themes</p>
              <p className="ppaa">Shopping cart</p>
              <p className="ppaa">Ecommerce hosting</p>
            </div>
            <div className="col-md-2">
              <h6 className="text-white et">ONLINE STORE</h6>
              <p className="ppaa">Mobile commerce</p>
              <p className="ppaa">Ecommerce software</p>
              <p className="ppaa">Online store builder</p>
              <p className="ppaa">Dropshipping Business</p>
              <p className="ppaa">Store Themesl</p>
            </div>
            <div className="col-md-2">
              <h6 className="text-white">POINT OF SALE</h6>
              <p className="ppaa">Point of sale</p>
              <p className="ppaa">Features</p>
              <p className="ppaa">Hardware</p>
            </div>
            <div className="col-md-2">
              <h6 className="text-white">SUPPORT</h6>
              <p className="ppaa">24/7 support</p>
              <p className="ppaa">Shopify help center</p>
              <p className="ppaa">Shopify community</p>
              <p className="ppaa">API Documentation</p>
              <p className="ppaa">Free Tools</p>
              <p className="ppaa">Free stock photos</p>
              <p className="ppaa">Websites for sale</p>
              <p className="ppaa">Logo maker</p>
              <p className="ppaa">Business name</p>
              <p className="ppaa">Research</p>
            </div>
            <div className="col-md-2">
              <h6 className="text-white">SHOPIFY</h6>
              <p className="ppaa">Contact</p>
              <p className="ppaa">Partner Program</p>
              <p className="ppaa">Affiliate program</p>
              <p className="ppaa">App Developers</p>
              <p className="ppaa">Investors</p>
              <p className="ppaa">Blog Topics</p>
              <p className="ppaa">Accessibility</p>
              <p className="ppaa">Community events</p>
            </div>
          </div>

          <div className="FonT text-start pt-5 ">
            <i class="fa-brands fa-facebook px-1"></i>
            <i class="fa-brands fa-twitter px-1"></i>
            <i class="fa-brands fa-youtube px-1"></i>
            <i class="fa-brands fa-instagram px-1"></i>
            <i class="fa-brands fa-linkedin px-1"></i>
            <i class="fa-brands fa-pinterest px-1"></i>
            <span className="ppaa text-end">Accessibility</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Footer;
