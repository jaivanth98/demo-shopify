import React from "react";
import "./Header.css";

function Header() {
  return (
    <div className="Rose">
      <div className="container">
        <div className="row pt-5 justify-content-around ">
          <div className=" col-md-3 mt-5 ">
            <h1 className="H1">The platform commerce is built on</h1>
            <h5 className="text-muted mt-2">
              Millions of the world's most successful brands trust Shopify to
              sell, ship and process payments anywhere.
            </h5>
            <input
              class="form-control mr-sm-2 mt-3"
              type="search"
              placeholder="Enter your e-mail"
              aria-label="Search"
            ></input>
            <button className="btn btn-success w-100 mt-2">Get started</button>
            <p className="Par mt-3">
              Try Shopify free for 14 days, no credit card required. By entering
              your email, you agree to receive marketing emails from Shopify.
            </p>
          </div>
          <div className="col-md-6 text-end img-fluid pt-4">
            <img
              src="https://www.hostforweb.com/storage/app/media/uploaded-files/1639759007458.jpeg"
              height={"420px"}
              width={"450px"}
              alt=""
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Header;
