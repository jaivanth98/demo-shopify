import React from "react";
import "./Navbar.css";

function Navbar() {
  return (
    <div>
      <div className="container-fluid">
        <nav class="navbar navbar-expand-sm navbar-dark fixed-top ">
          <div class="container-fluid">
            <img
              src="https://avatars.mds.yandex.net/i?id=fe47e05a4d27632070fa27b0da919800-5578090-images-thumbs&n=13"
              height={"55px"}
              alt=""
            />
            <button
              class="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#mynavbar"
            >
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse " id="mynavbar">
              <ul class="navbar-nav me-auto">
                <li class="nav-item">
                  <div class="dropdown">
                    <button
                      class="btn btn-outline dropdown-toggle "
                      type="button"
                      id="dropdownMenuButton"
                      data-toggle="dropdown"
                      aria-haspopup="true"
                      aria-expanded="false"
                    >
                      Start
                    </button>
                    <div
                      class="dropdown-menu"
                      aria-labelledby="dropdownMenuButton"
                    >
                      <a class="dropdown-item" href=".">
                        Action
                      </a>
                      <a class="dropdown-item" href=".">
                        Another action
                      </a>
                      <a class="dropdown-item" href=".">
                        Something else here
                      </a>
                    </div>
                  </div>
                </li>
                <li class="nav-item">
                  <div class="dropdown">
                    <button
                      class="btn btn-outline dropdown-toggle"
                      type="button"
                      id="dropdownMenuButton"
                      data-toggle="dropdown"
                      aria-haspopup="true"
                      aria-expanded="false"
                    >
                      Sell
                    </button>
                    <div
                      class="dropdown-menu"
                      aria-labelledby="dropdownMenuButton"
                    >
                      <a class="dropdown-item" href=".">
                        Action
                      </a>
                      <a class="dropdown-item" href=".">
                        Another action
                      </a>
                      <a class="dropdown-item" href=".">
                        Something else here
                      </a>
                    </div>
                  </div>
                </li>
                <li class="nav-item">
                  <div class="dropdown">
                    <button
                      class="btn btn-outline dropdown-toggle "
                      type="button"
                      id="dropdownMenuButton"
                      data-toggle="dropdown"
                      aria-haspopup="true"
                      aria-expanded="false"
                    >
                      Market
                    </button>
                    <div
                      class="dropdown-menu"
                      aria-labelledby="dropdownMenuButton"
                    >
                      <a class="dropdown-item" href=".">
                        Action
                      </a>
                      <a class="dropdown-item" href=".">
                        Another action
                      </a>
                      <a class="dropdown-item" href=".">
                        Something else here
                      </a>
                    </div>
                  </div>
                </li>
              </ul>
              <form class="d-flex">
                <div class="dropdown">
                  <button
                    class="btn btn-outline dropdown-toggle "
                    type="button"
                    id="dropdownMenuButton"
                    data-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="false"
                  >
                    Pricing
                  </button>
                  <div
                    class="dropdown-menu"
                    aria-labelledby="dropdownMenuButton"
                  >
                    <a class="dropdown-item" href=".">
                      Action
                    </a>
                    <a class="dropdown-item" href=".">
                      Another action
                    </a>
                    <a class="dropdown-item" href=".">
                      Something else here
                    </a>
                  </div>
                </div>
                <div class="dropdown">
                  <button
                    class="btn btn-outline dropdown-toggle"
                    type="button"
                    id="dropdownMenuButton"
                    data-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="false"
                  >
                    Learn
                  </button>
                  <div
                    class="dropdown-menu"
                    aria-labelledby="dropdownMenuButton"
                  >
                    <a class="dropdown-item" href=".">
                      Action
                    </a>
                    <a class="dropdown-item" href=".">
                      Another action
                    </a>
                    <a class="dropdown-item" href=".">
                      Something else here
                    </a>
                  </div>
                </div>
                <div class="dropdown">
                  <button
                    class="btn btn-outline dropdown-toggle "
                    type="button"
                    id="dropdownMenuButton"
                    data-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="false"
                  >
                    Login
                  </button>
                  <div
                    class="dropdown-menu"
                    aria-labelledby="dropdownMenuButton"
                  >
                    <a class="dropdown-item" href=".">
                      Action
                    </a>
                    <a class="dropdown-item" href=".">
                      Another action
                    </a>
                    <a class="dropdown-item" href=".">
                      Something else here
                    </a>
                  </div>
                </div>
                <button class="btn btn-success" type="button">
                  Start free trail
                </button>
              </form>
            </div>
          </div>
        </nav>
      </div>
    </div>
  );
}

export default Navbar;
