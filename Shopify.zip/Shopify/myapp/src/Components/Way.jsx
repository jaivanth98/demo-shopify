import React from "react";
import "./Way.css";

function Way() {
  return (
    <div className="container-fluid">
      <div className="row mt-5">
        <div className="col-md-6 px-5 WAy">
          <h1 className="pt-5">
            Get the help you need, <br />
            every step of the way
          </h1>

          <div className="row pt-5">
            <div className="col">
              <h5 className="SHop">Shopify support</h5>
              <p className="text-muted">
                Contact support 24/7, whether you’re troubleshooting issues or
                looking for business advice.
              </p>
              <a className="" href="0">
                Contact support
              </a>
            </div>
            <div className="col">
              <h5 className="SHop">Shopify App Store</h5>
              <p className="text-muted">
                Add features and functionality to your business with 6,000+ apps
                that integrate directly with Shopify.
              </p>
              <a className="" href="0">
                Visit the Shopify App Store
              </a>
            </div>
          </div>
          <div className="row">
            <div className="col">
              <h5 className="SHop">Shopify Experts Marketplace</h5>
              <p className="text-muted">
                Hire a Shopify expert to help you with everything from store
                setup to SEO.
              </p>
              <a className="" href="0">
                Explore the Shopify Experts Marketplace
              </a>
            </div>
            <div className="col"></div>
          </div>
        </div>
        <div className="col-md-6">
          <img
            src="https://cdn.shopify.com/shopifycloud/brochure/assets/home/help@desktop-9a31a38edab7cba3389c5d71eccb81ab32d24e0eeb40c8eac3568d98bc179e1e.jpg"
            alt=""
            height={"590px"}
          />
        </div>
      </div>

      <div className="mt-5 text-center">
        <h1>Start your business journey with Shopify</h1>
        <p className="text-muted pt-3">
          Try Shopify for free, and explore all the tools and services you need
          to start, run, and grow <br />
          your business.
        </p>
        <button className="btn btn-success">Get started</button>
      </div>
    </div>
  );
}

export default Way;
